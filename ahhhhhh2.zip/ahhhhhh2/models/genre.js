const db = require('../database/connection');

class Genre {
    static getAll(callback) {
        db.all('SELECT * FROM genres', callback);
    }

    static create(data, callback) {
        db.run('INSERT INTO genres (name) VALUES (?)', [data.name], callback);
    }

    static delete(id, callback) {
        db.run('DELETE FROM genres WHERE id = ?', [id], callback);
    }

    static update(id, name, callback) {
        db.run('UPDATE genres SET name = ? WHERE id = ?', [name, id], callback);
    }
}

module.exports = Genre;
