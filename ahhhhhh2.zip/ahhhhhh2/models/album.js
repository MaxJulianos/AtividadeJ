
const db = require('../database/connection');

class Album {
    static getAll(callback) {
        const query = `
            SELECT albums.*, artists.name AS artist_name, GROUP_CONCAT(genres.name) AS genres
            FROM albums
            LEFT JOIN artists ON albums.artist_id = artists.id
            LEFT JOIN album_genre ON albums.id = album_genre.album_id
            LEFT JOIN genres ON album_genre.genre_id = genres.id
            GROUP BY albums.id
        `;
        db.all(query, callback);
    }

    static create(data, callback) {
        const query = `
            INSERT INTO albums (title, release_year, cover, artist_id)
            VALUES (?, ?, ?, ?)
        `;
        db.run(query, [data.title, data.release_year, data.cover, data.artist_id], function (err) {
            if (err) return callback(err);
            const albumId = this.lastID;
            const genreQuery = `INSERT INTO album_genre (album_id, genre_id) VALUES (?, ?)`;
            data.genre_ids.forEach((genreId) => {
                db.run(genreQuery, [albumId, genreId]);
            });
            callback(null);
        });
    }

    static update(id, data, callback) {
        const query = `
            UPDATE albums
            SET title = ?, release_year = ?, cover = ?, artist_id = ?
            WHERE id = ?
        `;
        db.run(query, [data.title, data.release_year, data.cover, data.artist_id, id], function (err) {
            if (err) return callback(err);
            const deleteQuery = `DELETE FROM album_genre WHERE album_id = ?`;
            db.run(deleteQuery, [id], function () {
                const genreQuery = `INSERT INTO album_genre (album_id, genre_id) VALUES (?, ?)`;
                data.genre_ids.forEach((genreId) => {
                    db.run(genreQuery, [id, genreId]);
                });
                callback(null);
            });
        });
    }

    static delete(id, callback) {
        db.run(`DELETE FROM albums WHERE id = ?`, [id], callback);
    }

    static search(filters, callback) {
        let query = `
            SELECT albums.*, artists.name AS artist_name, GROUP_CONCAT(genres.name) AS genres
            FROM albums
            LEFT JOIN artists ON albums.artist_id = artists.id
            LEFT JOIN album_genre ON albums.id = album_genre.album_id
            LEFT JOIN genres ON album_genre.genre_id = genres.id
            WHERE 1=1
        `;
        const params = [];

        if (filters.title) {
            query += ` AND albums.title LIKE ?`;
            params.push(`%${filters.title}%`);
        }

        if (filters.artist) {
            query += ` AND artists.name LIKE ?`;
            params.push(`%${filters.artist}%`);
        }

        if (filters.genre) {
            query += ` AND genres.name LIKE ?`;
            params.push(`%${filters.genre}%`);
        }

        query += ` GROUP BY albums.id`;

        db.all(query, params, callback);
    }
}

module.exports = Album;
