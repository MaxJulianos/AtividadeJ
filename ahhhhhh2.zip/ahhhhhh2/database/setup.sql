-- Tabela de Artistas
CREATE TABLE IF NOT EXISTS artists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    genre TEXT NOT NULL
);

-- Tabela de Gêneros
CREATE TABLE IF NOT EXISTS genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);

-- Tabela de Álbuns
CREATE TABLE IF NOT EXISTS albums (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    release_year INTEGER NOT NULL,
    cover TEXT, -- Caminho ou URL para a capa do álbum
    artist_id INTEGER,
    FOREIGN KEY (artist_id) REFERENCES artists(id)
);

-- Tabela de Faixas (Tracks)
CREATE TABLE IF NOT EXISTS tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL, -- Nome da faixa
    album_id INTEGER,
    FOREIGN KEY (album_id) REFERENCES albums(id)
);

-- Tabela Relacional (Álbuns x Gêneros)
CREATE TABLE IF NOT EXISTS album_genres (
    album_id INTEGER,
    genre_id INTEGER,
    PRIMARY KEY (album_id, genre_id),
    FOREIGN KEY (album_id) REFERENCES albums(id),
    FOREIGN KEY (genre_id) REFERENCES genres(id)
);

-- Inserir dados iniciais na Tabela de Artistas
INSERT INTO artists (name, genre)
VALUES
    ('Artist 1', 'Rock'),
    ('Artist 2', 'Pop');

-- Inserir dados iniciais na Tabela de Gêneros
INSERT INTO genres (name)
VALUES
    ('Rock'),
    ('Pop'),
    ('Jazz'),
    ('Classical');

-- Inserir dados iniciais na Tabela de Álbuns
INSERT INTO albums (title, release_year, cover, artist_id)
VALUES
    ('Album 1', 2022, 'cover1.jpg', 1),
    ('Album 2', 2023, 'cover2.jpg', 2);

-- Inserir dados iniciais na Tabela de Faixas (Tracks)
INSERT INTO tracks (title, album_id)
VALUES
    ('Track 1', 1),
    ('Track 2', 1),
    ('Track 3', 2);

-- Inserir dados iniciais na Tabela Relacional (Álbuns x Gêneros)
INSERT INTO album_genres (album_id, genre_id)
VALUES
    (1, 1), -- Album 1 associado ao gênero Rock
    (2, 2), -- Album 2 associado ao gênero Pop
    (1, 3); -- Album 1 também associado ao gênero Jazz
